package com.petricia.librarymanagement.service;

import com.petricia.librarymanagement.model.Comment;
import com.petricia.librarymanagement.model.entity.CommentEntity;
import com.petricia.librarymanagement.repository.CommentRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CommentServiceImp {

    CommentRepository commentRepository;

    public void setCommentRepository(CommentRepository commentRepository) {
        this.commentRepository = commentRepository;
    }

    List<CommentEntity> getCommentsByBookExtId(long id) {

        Optional<List<CommentEntity>> result = Optional.ofNullable(commentRepository.findAllByBookExtId(id));

        if(result.isEmpty()) return new ArrayList<>(1);

        return result.get();
    }
}
