package com.petricia.librarymanagement.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
public class Comment {

    private String Id;

    private String author_name;

    private String content;

    private List<Comment> replies;
}
