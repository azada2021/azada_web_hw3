package com.petricia.librarymanagement.model.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;

@NoArgsConstructor
@Entity
@Data
public class CommentEntity {

    @Id
    private String Id;

    private String commentExtId;

    private String commentAuthorName;

    private String commentContent;
}
