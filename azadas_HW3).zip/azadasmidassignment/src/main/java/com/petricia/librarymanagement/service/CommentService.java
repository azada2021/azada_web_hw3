package com.petricia.librarymanagement.service;

import com.petricia.librarymanagement.model.entity.CommentEntity;
import com.petricia.librarymanagement.repository.CommentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

public interface CommentService {

    List<CommentEntity> getCommentsByBookExtId(long id);
}
